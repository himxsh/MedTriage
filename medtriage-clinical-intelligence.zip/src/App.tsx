import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import AuditLog from './components/AuditLog';
import { Screen } from './types';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');

  const navigate = (screen: Screen) => {
    setCurrentScreen(screen);
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen font-sans">
      {currentScreen === 'landing' && <LandingPage onNavigate={navigate} />}
      {currentScreen === 'dashboard' && <Dashboard onNavigate={navigate} />}
      {currentScreen === 'audit' && <AuditLog onNavigate={navigate} />}
    </div>
  );
}
