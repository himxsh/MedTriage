import React from 'react';
import { Search, Download, Settings, User, ChevronsLeft, ChevronsRight } from 'lucide-react';
import { AuditEntry } from '../types';

const MOCK_LOGS: AuditEntry[] = [
  {
    timestamp: '2023-10-24 14:22:01.004',
    clinicianId: 'DR_VANCE_42',
    caseRef: '#8821-X',
    action: 'TRIAGE_UPGRADE',
    prevLevel: 'LEVEL 3',
    newLevel: 'LEVEL 2',
    status: 'upgrade'
  },
  {
    timestamp: '2023-10-24 14:15:45.912',
    clinicianId: 'RN_CHEN_19',
    caseRef: '#8825-A',
    action: 'INITIAL_ASSESS',
    prevLevel: 'NULL',
    newLevel: 'LEVEL 4',
    status: 'initial'
  },
  {
    timestamp: '2023-10-24 14:02:10.552',
    clinicianId: 'DR_VANCE_42',
    caseRef: '#8819-C',
    action: 'DISCHARGE_AUTH',
    prevLevel: 'LEVEL 2',
    newLevel: 'N/A',
    status: 'discharge'
  },
  {
    timestamp: '2023-10-24 13:55:12.118',
    clinicianId: 'RN_SMITH_04',
    caseRef: '#8822-L',
    action: 'TRIAGE_DOWNGRADE',
    prevLevel: 'LEVEL 1',
    newLevel: 'LEVEL 2',
    status: 'downgrade'
  },
  {
    timestamp: '2023-10-24 13:48:30.000',
    clinicianId: 'DR_ALTO_88',
    caseRef: '#8821-X',
    action: 'RECORD_OPEN',
    prevLevel: 'LEVEL 3',
    newLevel: 'LEVEL 3',
    status: 'record'
  },
  {
    timestamp: '2023-10-24 13:30:05.421',
    clinicianId: 'SYS_CORE_AUTO',
    caseRef: '#8812-B',
    action: 'DATA_CORRUPTION_ERR',
    prevLevel: 'LEVEL 5',
    newLevel: 'LOCKDOWN',
    status: 'error'
  },
  {
    timestamp: '2023-10-24 13:12:44.201',
    clinicianId: 'RN_CHEN_19',
    caseRef: '#8830-Z',
    action: 'VITAL_ENTRY',
    prevLevel: 'LEVEL 3',
    newLevel: 'LEVEL 3',
    status: 'vital'
  },
  {
    timestamp: '2023-10-24 12:55:00.002',
    clinicianId: 'DR_VANCE_42',
    caseRef: '#8819-C',
    action: 'MED_DISPENSE',
    prevLevel: 'LEVEL 2',
    newLevel: 'LEVEL 2',
    status: 'dispense'
  }
];

interface AuditLogProps {
  onNavigate: (screen: 'landing' | 'dashboard') => void;
}

export default function AuditLog({ onNavigate }: AuditLogProps) {
  return (
    <div className="min-h-screen flex flex-col bg-background-linen text-black font-mono">
      {/* Header */}
      <header className="flex items-center justify-between border-b-2 border-black px-6 py-4 bg-background-linen">
        <div className="flex items-center gap-4 text-primary cursor-pointer" onClick={() => onNavigate('landing')}>
          <div className="w-6 h-6 bg-primary/20 flex items-center justify-center">
            <span className="text-primary text-xs font-bold">M</span>
          </div>
          <h2 className="text-black text-xl font-bold leading-tight tracking-tight font-bebas">
            MedTriage <span className="text-primary text-sm ml-2 tracking-widest font-mono">v4.2.0</span>
          </h2>
        </div>
        <div className="flex flex-1 justify-end gap-6 items-center">
          <div className="flex items-center gap-2 border-2 border-black px-3 py-1 bg-white">
            <Search className="w-4 h-4 text-primary" />
            <input 
              className="bg-transparent border-none focus:outline-none text-xs font-mono placeholder:text-neutral-400 w-48" 
              placeholder="FILTER LOGS..." 
              type="text"
            />
          </div>
          <div className="flex gap-4">
            <button className="flex items-center justify-center border-2 border-black p-2 hover:bg-primary/10 text-neutral-700 cursor-pointer">
              <Download className="w-4 h-4" />
            </button>
            <button className="flex items-center justify-center border-2 border-black p-2 hover:bg-primary/10 text-neutral-700 cursor-pointer">
              <Settings className="w-4 h-4" />
            </button>
            <div className="h-8 w-[1px] bg-black"></div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-[10px] text-neutral-500 leading-none">SYSTEM_ADMIN</p>
                <p className="text-xs font-bold text-black uppercase">J. VANCE</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center border border-primary">
                <span className="text-primary text-xs font-bold">JV</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 px-6 py-8">
        {/* Title Section */}
        <div className="mb-8">
          <h1 className="text-6xl font-bebas tracking-wider text-black mb-2">AUDIT LOG</h1>
          <div className="h-1 w-full bg-black mb-4"></div>
          <div className="flex justify-between items-end text-[10px] text-neutral-600 font-mono tracking-widest uppercase">
            <span>System Status: Operational // Security Level: 4</span>
            <span>Records: 42,901 Found // showing 1-25</span>
          </div>
        </div>

        {/* Table */}
        <div className="border-2 border-black overflow-hidden bg-white">
          <table className="w-full text-left border-collapse">
            <thead className="bg-neutral-100 border-b-2 border-black">
              <tr>
                <th className="px-4 py-3 text-[11px] font-bold text-black border-r-2 border-black tracking-widest uppercase">Timestamp</th>
                <th className="px-4 py-3 text-[11px] font-bold text-black border-r-2 border-black tracking-widest uppercase">Clinician ID</th>
                <th className="px-4 py-3 text-[11px] font-bold text-black border-r-2 border-black tracking-widest uppercase">Case Reference</th>
                <th className="px-4 py-3 text-[11px] font-bold text-black border-r-2 border-black tracking-widest uppercase">Action Protocol</th>
                <th className="px-4 py-3 text-[11px] font-bold text-black border-r-2 border-black tracking-widest uppercase text-center">Prev Level</th>
                <th className="px-4 py-3 text-[11px] font-bold text-black tracking-widest uppercase text-center">New Level</th>
              </tr>
            </thead>
            <tbody className="text-xs font-mono">
              {MOCK_LOGS.map((log, i) => (
                <tr key={i} className="border-b border-black/10 hover:bg-black/5 transition-colors">
                  <td className="px-4 py-3 text-neutral-600 border-r-2 border-black">{log.timestamp}</td>
                  <td className="px-4 py-3 text-black font-bold border-r-2 border-black">{log.clinicianId}</td>
                  <td className="px-4 py-3 text-primary border-r-2 border-black font-bold underline cursor-pointer">{log.caseRef}</td>
                  <td className="px-4 py-3 border-r-2 border-black">
                    <span className={`border px-2 py-0.5 text-[9px] font-bold ${
                      log.status === 'upgrade' || log.status === 'downgrade' ? 'bg-primary/20 border-primary text-black' :
                      log.status === 'initial' || log.status === 'record' || log.status === 'vital' || log.status === 'dispense' ? 'bg-neutral-200 border-neutral-400 text-neutral-700' :
                      log.status === 'discharge' ? 'bg-green-100 border-green-600 text-green-700' :
                      'bg-red-100 border-red-600 text-red-700'
                    }`}>
                      {log.action}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center border-r-2 border-black text-neutral-400">{log.prevLevel}</td>
                  <td className={`px-4 py-3 text-center font-bold ${
                    log.newLevel === 'LOCKDOWN' || log.newLevel === 'LEVEL 2' ? 'text-red-600' : 
                    log.newLevel === 'LEVEL 2' && log.status === 'downgrade' ? 'text-green-600' : 'text-black'
                  }`}>
                    {log.newLevel}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination & Footer Actions */}
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-6 font-mono">
          <div className="text-[10px] text-neutral-500">
            AUTO_REFRESH: ENABLED (30s)
          </div>
          <div className="flex items-center gap-1">
            <button className="border-2 border-black p-1 text-neutral-400 hover:text-primary transition-colors cursor-pointer">
              <ChevronsLeft className="w-4 h-4" />
            </button>
            <button className="border-2 border-black px-3 py-1 bg-black text-white text-xs font-bold cursor-pointer">1</button>
            <button className="border-2 border-black px-3 py-1 hover:bg-neutral-200 text-xs text-neutral-700 cursor-pointer">2</button>
            <button className="border-2 border-black px-3 py-1 hover:bg-neutral-200 text-xs text-neutral-700 cursor-pointer">3</button>
            <span className="px-2 text-neutral-400">...</span>
            <button className="border-2 border-black px-3 py-1 hover:bg-neutral-200 text-xs text-neutral-700 cursor-pointer">142</button>
            <button className="border-2 border-black p-1 text-neutral-400 hover:text-primary transition-colors cursor-pointer">
              <ChevronsRight className="w-4 h-4" />
            </button>
          </div>
          <div className="flex gap-4">
            <button className="text-[11px] border-2 border-black px-4 py-1.5 bg-white text-black hover:bg-black hover:text-white transition-all font-bold cursor-pointer">
              EXPORT_CSV
            </button>
            <button className="text-[11px] border-2 border-black px-4 py-1.5 bg-white text-black hover:bg-black hover:text-white transition-all font-bold cursor-pointer">
              PRINT_LOG
            </button>
          </div>
        </div>
      </main>

      {/* Bottom Status Bar */}
      <footer className="bg-neutral-200 border-t-2 border-black px-6 py-2 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex flex-wrap items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-600 rounded-full"></div>
            <span className="text-[10px] text-neutral-700 font-mono">LOG_DAEMON: ACTIVE</span>
          </div>
          <div className="text-[10px] text-neutral-500 font-mono">ENCRYPTION: AES-256</div>
          <div className="text-[10px] text-neutral-500 font-mono">LOC: SEC_SERVER_A4</div>
        </div>
        <div className="text-[10px] text-neutral-500 font-mono tracking-tighter uppercase">
          © 2024 MEDTRIAGE INFRASTRUCTURE - UNCLASSIFIED // FOUO
        </div>
      </footer>
    </div>
  );
}
