import React, { useState } from 'react';
import { LayoutDashboard, History, BarChart3, Settings, User, Activity } from 'lucide-react';
import { PatientCase } from '../types';

const MOCK_CASES: PatientCase[] = [
  {
    id: '#00142',
    patient: 'John Doe',
    complaint: 'CHEST PAIN / SHORTNESS OF BREATH',
    urgency: 'CRITICAL',
    confidence: 92,
    time: '02:15',
    age: 54,
    sex: 'M',
    arrival: '12:38 UTC',
    vitals: { bp: '145/92', hr: 112, spo2: '94%', temp: '98.6 F' }
  },
  {
    id: '#00143',
    patient: 'Jane Smith',
    complaint: 'ABDOMINAL PAIN / ACUTE',
    urgency: 'HIGH',
    confidence: 88,
    time: '05:30',
    age: 32,
    sex: 'F',
    arrival: '12:45 UTC',
    vitals: { bp: '110/70', hr: 85, spo2: '98%', temp: '101.2 F' }
  },
  {
    id: '#00144',
    patient: 'Bob White',
    complaint: 'LACERATION / RIGHT HAND',
    urgency: 'MODERATE',
    confidence: 75,
    time: '08:45',
    age: 45,
    sex: 'M',
    arrival: '13:10 UTC',
    vitals: { bp: '128/82', hr: 72, spo2: '99%', temp: '98.4 F' }
  }
];

interface DashboardProps {
  onNavigate: (screen: 'landing' | 'audit') => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [selectedCase, setSelectedCase] = useState<PatientCase>(MOCK_CASES[0]);

  return (
    <div className="flex h-screen w-full overflow-hidden">
      {/* Sidebar */}
      <aside className="w-[200px] flex-shrink-0 flex flex-col border-r-2 border-black bg-background-linen">
        <div className="p-6 border-b-2 border-black cursor-pointer" onClick={() => onNavigate('landing')}>
          <h1 className="font-bebas text-2xl tracking-widest text-black">MEDTRIAGE</h1>
          <p className="text-[10px] font-mono uppercase text-black/60 tracking-[0.2em]">Clinical Portal v2.0</p>
        </div>
        <nav className="flex-1 py-4">
          <div className="space-y-1">
            <a className="flex items-center gap-3 px-6 py-3 bg-black/5 text-black border-r-4 border-black" href="#">
              <LayoutDashboard className="w-4 h-4" />
              <span className="font-mono text-xs font-bold uppercase tracking-tighter">Queue</span>
            </a>
            <a className="flex items-center gap-3 px-6 py-3 text-black/40 hover:text-black transition-colors" href="#">
              <History className="w-4 h-4" />
              <span className="font-mono text-xs font-bold uppercase tracking-tighter">History</span>
            </a>
            <a className="flex items-center gap-3 px-6 py-3 text-black/40 hover:text-black transition-colors" href="#">
              <BarChart3 className="w-4 h-4" />
              <span className="font-mono text-xs font-bold uppercase tracking-tighter">Analytics</span>
            </a>
            <a className="flex items-center gap-3 px-6 py-3 text-black/40 hover:text-black transition-colors" href="#">
              <Settings className="w-4 h-4" />
              <span className="font-mono text-xs font-bold uppercase tracking-tighter">Settings</span>
            </a>
          </div>
        </nav>
        <div className="p-4 border-t-2 border-black">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-black/10 flex items-center justify-center border border-black">
              <User className="w-4 h-4" />
            </div>
            <div className="overflow-hidden">
              <p className="font-mono text-[10px] font-bold text-black truncate uppercase">Dr. Henderson</p>
              <p className="font-mono text-[8px] text-black/60 truncate uppercase italic">Chief Resident</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b-2 border-black flex items-center justify-between px-8 bg-background-linen shrink-0">
          <h2 className="font-bebas text-3xl tracking-[0.1em] text-black">TRIAGE DASHBOARD</h2>
          <div className="flex items-center gap-8">
            <div className="flex items-center font-mono text-sm tracking-widest text-black/80">
              <span className="w-2 h-2 bg-primary rounded-full mr-2 animate-pulse"></span>
              LIVE CONNECTED
            </div>
            <div className="font-mono text-xl text-black tracking-tighter font-bold">
              12:45:00 UTC
            </div>
          </div>
        </header>

        {/* Status Row */}
        <div className="flex divide-x-2 divide-black border-b-2 border-black shrink-0">
          <div className="flex-1 p-6 bg-background-linen hover:bg-black/5 transition-colors">
            <p className="font-mono text-[10px] font-bold text-black/50 uppercase tracking-widest mb-1">Pending</p>
            <p className="font-bebas text-5xl text-black">24</p>
          </div>
          <div className="flex-1 p-6 bg-background-linen hover:bg-black/5 transition-colors">
            <p className="font-mono text-[10px] font-bold text-black/50 uppercase tracking-widest mb-1">In Review</p>
            <p className="font-bebas text-5xl text-primary">08</p>
          </div>
          <div className="flex-1 p-6 bg-background-linen hover:bg-black/5 transition-colors">
            <p className="font-mono text-[10px] font-bold text-black/50 uppercase tracking-widest mb-1">Completed</p>
            <p className="font-bebas text-5xl text-black">142</p>
          </div>
        </div>

        {/* Queue & Details */}
        <div className="flex flex-1 overflow-hidden">
          {/* Patient Queue */}
          <main className="flex-1 overflow-y-auto bg-background-linen">
            <table className="w-full text-left font-mono text-xs border-collapse">
              <thead className="sticky top-0 bg-background-linen z-10 border-b-2 border-black">
                <tr>
                  <th className="p-4 text-black font-bold uppercase tracking-tighter">Case ID</th>
                  <th className="p-4 text-black font-bold uppercase tracking-tighter">Patient</th>
                  <th className="p-4 text-black font-bold uppercase tracking-tighter">Chief Complaint</th>
                  <th className="p-4 text-black font-bold uppercase tracking-tighter">Urgency</th>
                  <th className="p-4 text-black font-bold uppercase tracking-tighter">Confidence</th>
                  <th className="p-4 text-black font-bold uppercase tracking-tighter">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y-2 divide-black/10">
                {MOCK_CASES.map((c) => (
                  <tr 
                    key={c.id}
                    onClick={() => setSelectedCase(c)}
                    className={`hover:bg-black/5 cursor-pointer transition-colors ${selectedCase.id === c.id ? 'bg-black/5' : 'bg-white'}`}
                  >
                    <td className="p-4 text-primary font-bold">{c.id}</td>
                    <td className="p-4 text-black uppercase">{c.patient}</td>
                    <td className="p-4 text-black/60">{c.complaint}</td>
                    <td className="p-4">
                      <span className={`px-2 py-1 font-bold text-white uppercase ${
                        c.urgency === 'CRITICAL' ? 'bg-urgency-critical' : 
                        c.urgency === 'HIGH' ? 'bg-urgency-high text-black' : 'bg-urgency-moderate'
                      }`}>
                        {c.urgency}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="w-full bg-black/10 h-1 max-w-[100px]">
                        <div className="bg-primary h-1" style={{ width: `${c.confidence}%` }}></div>
                      </div>
                      <span className="mt-1 block text-[10px] text-black/50">{c.confidence}%</span>
                    </td>
                    <td className="p-4 text-black/60">{c.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </main>

          {/* Detail Panel */}
          <aside className="w-[350px] border-l-2 border-black bg-background-linen overflow-y-auto flex flex-col">
            <div className="p-6 border-b-2 border-black flex-shrink-0">
              <p className="font-mono text-[10px] font-bold text-primary uppercase tracking-[0.2em] mb-4">Selected Case</p>
              <h3 className="font-bebas text-5xl text-black mb-2">CASE {selectedCase.id}</h3>
              <p className="font-mono text-xs text-black/60 uppercase leading-loose">
                Patient: {selectedCase.patient}<br/>
                Age/Sex: {selectedCase.age} / {selectedCase.sex}<br/>
                Arrival: {selectedCase.arrival}
              </p>
            </div>
            <div className="p-6 border-b-2 border-black flex-shrink-0">
              <p className="font-mono text-[10px] font-bold text-black/50 uppercase tracking-widest mb-4">AI Confidence Score</p>
              <div className="flex items-baseline gap-2">
                <span className="font-bebas text-8xl text-primary leading-none">{selectedCase.confidence}</span>
                <span className="font-bebas text-3xl text-primary/40 leading-none">%</span>
              </div>
            </div>
            <div className="p-6 flex-1 bg-white/30 space-y-6">
              <div>
                <p className="font-mono text-[10px] font-bold text-black/50 uppercase tracking-widest mb-2">Vitals Summary</p>
                <div className="grid grid-cols-2 gap-4 font-mono">
                  <div className="border-l-2 border-primary/40 pl-3">
                    <p className="text-[10px] text-black/50">BP</p>
                    <p className="text-sm font-bold text-black">{selectedCase.vitals.bp}</p>
                  </div>
                  <div className="border-l-2 border-primary/40 pl-3">
                    <p className="text-[10px] text-black/50">HR</p>
                    <p className={`text-sm font-bold ${selectedCase.vitals.hr > 100 ? 'text-urgency-critical' : 'text-black'}`}>
                      {selectedCase.vitals.hr}
                    </p>
                  </div>
                  <div className="border-l-2 border-primary/40 pl-3">
                    <p className="text-[10px] text-black/50">SpO2</p>
                    <p className="text-sm font-bold text-black">{selectedCase.vitals.spo2}</p>
                  </div>
                  <div className="border-l-2 border-primary/40 pl-3">
                    <p className="text-[10px] text-black/50">TEMP</p>
                    <p className="text-sm font-bold text-black">{selectedCase.vitals.temp}</p>
                  </div>
                </div>
              </div>
              <div className="pt-4 space-y-3">
                <button className="w-full py-4 border-2 border-black text-black font-mono text-xs font-bold uppercase tracking-widest hover:bg-black/5 transition-colors cursor-pointer">
                  Mark Complete
                </button>
                <button className="w-full py-4 border-2 border-urgency-critical text-urgency-critical font-mono text-xs font-bold uppercase tracking-widest hover:bg-urgency-critical/10 transition-colors cursor-pointer">
                  Escalate
                </button>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
