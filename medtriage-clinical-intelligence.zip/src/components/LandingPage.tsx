import React from 'react';
import { LayoutGrid, ShieldCheck, Stethoscope, ClipboardList } from 'lucide-react';
import { motion } from 'motion/react';

interface LandingPageProps {
  onNavigate: (screen: 'dashboard' | 'audit') => void;
}

export default function LandingPage({ onNavigate }: LandingPageProps) {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="flex items-center justify-between px-6 md:px-10 py-6 brutalist-rule-x">
        <div className="flex items-center gap-4">
          <LayoutGrid className="w-8 h-8 text-primary" />
          <h2 className="text-2xl font-bold tracking-tighter font-mono">MEDTRIAGE</h2>
        </div>
        <div className="hidden md:flex items-center gap-10 font-mono text-sm uppercase">
          <a className="hover:text-primary transition-colors" href="#">Platform</a>
          <a className="hover:text-primary transition-colors" href="#">Security</a>
          <a className="hover:text-primary transition-colors" href="#">API</a>
          <a className="hover:text-primary transition-colors" href="#">Docs</a>
          <button 
            onClick={() => onNavigate('dashboard')}
            className="border-2 border-primary bg-transparent text-primary px-6 py-2 font-bold hover:bg-primary hover:text-white transition-all cursor-pointer"
          >
            GET STARTED
          </button>
        </div>
      </header>

      {/* Hero */}
      <main className="flex-grow">
        <section className="flex flex-col items-center justify-center text-center py-20 md:py-32 px-6 md:px-10 brutalist-rule-x">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-bebas text-[80px] md:text-[180px] leading-[0.85] text-black mb-8 tracking-tight"
          >
            TRIAGE. FASTER.
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="font-mono text-primary text-lg md:text-2xl mb-12 uppercase tracking-widest"
          >
            AI-powered clinical intelligence. De-identified. Real-time.
          </motion.p>
          <button 
            onClick={() => onNavigate('dashboard')}
            className="group relative inline-flex items-center justify-center border-2 border-primary bg-background-linen px-12 py-5 text-black font-mono text-lg uppercase transition-all hover:bg-primary hover:text-white cursor-pointer"
          >
            SUBMIT INTAKE
          </button>
        </section>

        {/* Stats */}
        <section className="grid grid-cols-1 md:grid-cols-3 brutalist-rule-x">
          <div className="p-10 md:p-16 flex flex-col items-start gap-4 brutalist-rule-y">
            <span className="text-6xl md:text-7xl font-bold font-mono tracking-tighter">12ms</span>
            <span className="text-primary font-mono uppercase tracking-widest text-sm">avg response</span>
          </div>
          <div className="p-10 md:p-16 flex flex-col items-start gap-4 brutalist-rule-y">
            <span className="text-6xl md:text-7xl font-bold font-mono tracking-tighter">99.4%</span>
            <span className="text-primary font-mono uppercase tracking-widest text-sm">extraction accuracy</span>
          </div>
          <div className="p-10 md:p-16 flex flex-col items-start gap-4">
            <span className="text-6xl md:text-7xl font-bold font-mono tracking-tighter uppercase">HIPAA-SAFE</span>
            <span className="text-primary font-mono uppercase tracking-widest text-sm">de-identified</span>
          </div>
        </section>

        {/* Features */}
        <section className="grid grid-cols-1 md:grid-cols-3 brutalist-rule-x bg-black/5">
          <div className="p-10 md:p-16 flex flex-col gap-8 brutalist-rule-y">
            <ShieldCheck className="text-primary w-12 h-12" />
            <div className="flex flex-col gap-4">
              <h3 className="text-3xl font-bold uppercase font-bebas tracking-wide">De-Identification Engine</h3>
              <p className="text-black/70 font-mono text-sm leading-relaxed">
                Automated removal of PII/PHI with high precision. Built for rigorous compliance standards.
              </p>
            </div>
          </div>
          <div className="p-10 md:p-16 flex flex-col gap-8 brutalist-rule-y">
            <Stethoscope className="text-primary w-12 h-12" />
            <div className="flex flex-col gap-4">
              <h3 className="text-3xl font-bold uppercase font-bebas tracking-wide">Clinical NER + UMLS</h3>
              <p className="text-black/70 font-mono text-sm leading-relaxed">
                Named Entity Recognition mapped to global standards. Instant medical semantic mapping.
              </p>
            </div>
          </div>
          <div className="p-10 md:p-16 flex flex-col gap-8">
            <ClipboardList className="text-primary w-12 h-12" />
            <div className="flex flex-col gap-4">
              <h3 className="text-3xl font-bold uppercase font-bebas tracking-wide">Real-Time Triage Queue</h3>
              <p className="text-black/70 font-mono text-sm leading-relaxed">
                Instantaneous prioritization of clinical cases. Sub-millisecond queuing architecture.
              </p>
            </div>
          </div>
        </section>

        {/* Global Nodes */}
        <section className="h-[400px] w-full relative brutalist-rule-x overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent"></div>
          <div className="absolute inset-0 flex items-center justify-center border-4 border-dashed border-black m-6 md:m-10">
            <div className="text-center">
              <h2 className="font-bebas text-5xl md:text-6xl text-primary mb-4">GLOBAL NODES</h2>
              <p className="font-mono text-sm uppercase tracking-widest text-black">Active deployment in 42 regions</p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="p-6 md:p-10 font-mono text-xs uppercase text-black/60">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-6">
          <div className="flex flex-wrap justify-center gap-6 md:gap-10">
            <a className="hover:text-primary transition-colors" href="#">System Status: Optimal</a>
            <a className="hover:text-primary transition-colors" href="#">Security Protocols</a>
            <a className="hover:text-primary transition-colors" href="#">Privacy Policy</a>
            <button onClick={() => onNavigate('audit')} className="hover:text-primary transition-colors cursor-pointer">Audit Logs</button>
          </div>
          <div>
            © 2024 MEDTRIAGE INTELLIGENCE CORP
          </div>
        </div>
        <div className="h-[2px] w-full bg-black"></div>
      </footer>
    </div>
  );
}
